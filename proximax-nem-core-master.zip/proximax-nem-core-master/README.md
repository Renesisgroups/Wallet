NEM Core
====================

[![Build Status](https://travis-ci.org/NemProject/nem.core.svg?branch=master)](https://travis-ci.org/NemProject/nem.core)

The NEM core is an important part for both NIS and NCC. Arguably one of the  most interesting parts would be org.nem.core.crypto, which includes all cryptographic procedures like signing and verifying of signatures.

Above that core includes building blocks like Transactions, Blocks and Messages.

compilation:

    mvn install
    
    
## Forked Version

This is ProximaX's forked version of NEM's [nem.core](https://github.com/NemProject/nem.core) project.
