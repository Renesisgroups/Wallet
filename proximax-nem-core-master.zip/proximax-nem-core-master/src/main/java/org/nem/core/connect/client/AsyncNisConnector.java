package org.nem.core.connect.client;

/**
 * An asynchronous NIS connector.
 */
@SuppressWarnings("unused")
public interface AsyncNisConnector extends AsyncNemConnector<NisApiId> {
}